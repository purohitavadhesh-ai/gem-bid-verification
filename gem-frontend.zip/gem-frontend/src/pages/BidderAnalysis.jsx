import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import TopNav from "../components/TopNav";
import StatusBadge from "../components/StatusBadge";
import ComplianceRing from "../components/ComplianceRing";
import ChecklistItem from "../components/ChecklistItem";
import { getTenderById, getBiddersForTender, getBidderResults, submitBidderDecision } from "../data/mockData";

export default function BidderAnalysis() {
  const { tenderId } = useParams();
  const navigate = useNavigate();

  const [tender, setTender] = useState(null);
  const [bidders, setBidders] = useState([]);
  const [selectedBidderId, setSelectedBidderId] = useState(null);
  const [results, setResults] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    getTenderById(tenderId).then(setTender); // GET /tenders/{id}
    getBiddersForTender(tenderId).then((list) => {
      // GET /tenders/{id}/bidders
      setBidders(list);
      const defaultBidder = list.find((b) => b.status === "Moderate") ?? list[0];
      if (defaultBidder) setSelectedBidderId(defaultBidder.id);
    });
  }, [tenderId]);

  useEffect(() => {
    if (selectedBidderId) {
      getBidderResults(selectedBidderId).then(setResults); // GET /tenders/{id}/bidders/{bidderId}/results
    }
  }, [selectedBidderId]);

  async function handleDecision(decision) {
    setSubmitting(true);
    try {
      await submitBidderDecision(selectedBidderId, decision); // POST .../decision
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-surface">
      <TopNav />

      <main className="mx-auto max-w-7xl px-6 py-8">
        {/* Breadcrumb */}
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-navy-800/60">
            Tender Details <span className="mx-1">›</span> Bidder Analysis
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => navigate("/dashboard")}
              className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold text-navy-800 hover:bg-white"
            >
              Back to List
            </button>
            <button className="rounded-md bg-navy-950 px-3 py-1.5 text-xs font-semibold text-white hover:bg-navy-800">
              Export Bid Evaluation
            </button>
          </div>
        </div>

        <h1 className="mb-6 text-xl font-bold text-navy-950">
          {tenderId}: {tender?.title}
        </h1>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[280px_1fr]">
          {/* Sidebar: bidder list */}
          <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-navy-800/60">
              Submitted Bidders ({bidders.length})
            </p>
            <div className="space-y-2">
              {bidders.map((b) => (
                <button
                  key={b.id}
                  onClick={() => setSelectedBidderId(b.id)}
                  className={`w-full rounded-lg border px-3 py-2.5 text-left transition-colors ${
                    selectedBidderId === b.id
                      ? "border-petrol-500 bg-petrol-500/5"
                      : "border-border hover:bg-surface"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-navy-950">{b.name}</span>
                    <span className="text-sm font-bold text-navy-950">{b.score}%</span>
                  </div>
                  <div className="mt-1 flex items-center justify-between">
                    <span className="text-xs text-navy-800/50">Submitted {b.submittedAgo}</span>
                    <StatusBadge status={b.status} />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Main detail panel */}
          {results && (
            <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-6 border-b border-border pb-6">
                <div className="flex items-center gap-5">
                  <ComplianceRing percent={results.score} />
                  <div>
                    <h2 className="text-lg font-bold text-navy-950">{results.name}</h2>
                    <div className="mt-1">
                      <StatusBadge status={`${results.riskLevel} Risk`.replace("Non-Compliant Risk", "Non-Compliant")} />
                      <span className="ml-2 text-xs text-navy-800/50">Triggered</span>
                    </div>
                    <p className="mt-2 max-w-md text-sm text-navy-800/70">{results.subtitle}</p>
                  </div>
                </div>
                <div className="text-right text-sm text-navy-800/70">
                  <p>
                    GeM Bid Ref: <span className="font-medium text-navy-950">{results.gemBidRef}</span>
                  </p>
                  <p>
                    Bid Value: <span className="font-medium text-navy-950">{results.bidValue}</span>
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-8 py-6 md:grid-cols-2">
                <div>
                  <h3 className="mb-2 text-sm font-semibold text-navy-950">Mandatory Documents</h3>
                  <div>
                    {results.mandatoryDocuments.map((item) => (
                      <ChecklistItem key={item.label} {...item} />
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="mb-2 text-sm font-semibold text-navy-950">Financial &amp; Technical Specs</h3>
                  <div>
                    {results.financialTechnical.map((item) => (
                      <ChecklistItem key={item.label} {...item} />
                    ))}
                  </div>
                </div>
              </div>

              <div className="rounded-lg bg-status-warn-bg px-4 py-3 text-sm text-status-warn">
                {results.aiSummary}
              </div>

              <div className="mt-5 flex flex-wrap justify-end gap-3">
                <button
                  disabled={submitting}
                  onClick={() => handleDecision("flag_reject")}
                  className="rounded-md border border-status-fail px-4 py-2 text-sm font-semibold text-status-fail hover:bg-status-fail-bg disabled:opacity-50"
                >
                  Flag &amp; Reject
                </button>
                <button
                  disabled={submitting}
                  onClick={() => handleDecision("request_correction")}
                  className="rounded-md border border-status-warn px-4 py-2 text-sm font-semibold text-status-warn hover:bg-status-warn-bg disabled:opacity-50"
                >
                  Request Correction
                </button>
                <button
                  disabled={submitting}
                  onClick={() => handleDecision("approve")}
                  className="rounded-md bg-status-pass px-4 py-2 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-50"
                >
                  Approve
                </button>
              </div>
            </div>
          )}
        </div>

        <p className="mt-6 rounded-md border border-border bg-white/60 px-4 py-3 text-xs text-navy-800/60">
          Final compliance decisions are made solely by the procurement officer. AI-generated verdicts are advisory
          and require human confirmation before any bid is approved or rejected.
        </p>
      </main>
    </div>
  );
}
