import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from "../data/mockData";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password); // POST /auth/login
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen grid-cols-1 md:grid-cols-2">
      {/* Left: illustration / brand panel */}
      <div className="hidden flex-col justify-between bg-navy-950 p-10 text-white md:flex">
        <div>
          <p className="text-xs uppercase tracking-wide text-white/60">Ministry of Petroleum &amp; Natural Gas</p>
          <p className="text-xs text-white/60">Government of India</p>
        </div>

        <div className="flex flex-1 flex-col items-center justify-center gap-6 py-10">
          <div className="flex h-40 w-40 items-center justify-center rounded-full bg-petrol-600/20 ring-1 ring-petrol-500/40">
            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-petrol-600 text-3xl">
              🛡️
            </div>
          </div>
          <p className="text-center text-xs text-white/50">[ AI Security Illustration ]</p>
        </div>

        <div className="rounded-xl bg-white/5 p-5 ring-1 ring-white/10">
          <p className="text-base font-semibold">Real-Time GeM Bidder Integrity Scan</p>
          <p className="mt-2 text-sm text-white/60">
            Auto-validating corporate documents, technical specs, and financial risk profiles instantly using AI
            models.
          </p>
        </div>
      </div>

      {/* Right: login form */}
      <div className="flex flex-col items-center justify-center bg-surface p-8">
        <div className="w-full max-w-sm">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-md bg-petrol-500 text-sm font-bold text-white">
              GeM
            </div>
            <h1 className="text-xl font-bold text-navy-950">AI Bid Compliance Verification</h1>
            <p className="mt-1 text-sm text-navy-800/70">
              Intelligent Compliance Verification for Government Procurement via GeM Portal
            </p>
          </div>

          <form onSubmit={handleSubmit} className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <label className="mb-1 block text-sm font-medium text-navy-950" htmlFor="email">
              Officer ID / NIC Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="rajesh.kumar@nic.in"
              className="mb-4 w-full rounded-md border border-border px-3 py-2 text-sm outline-none focus:border-petrol-500 focus:ring-2 focus:ring-petrol-500/20"
            />

            <label className="mb-1 block text-sm font-medium text-navy-950" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="mb-5 w-full rounded-md border border-border px-3 py-2 text-sm outline-none focus:border-petrol-500 focus:ring-2 focus:ring-petrol-500/20"
            />

            {error && <p className="mb-4 text-sm text-status-fail">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-md bg-petrol-600 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-petrol-500 disabled:opacity-60"
            >
              {loading ? "Signing in…" : "Login"}
            </button>
          </form>

          <p className="mt-5 text-center text-xs text-navy-800/50">
            Secured by National Informatics Centre (NIC) • 2026
          </p>
        </div>
      </div>
    </div>
  );
}
