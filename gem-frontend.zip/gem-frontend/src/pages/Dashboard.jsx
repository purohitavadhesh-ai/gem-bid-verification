import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import TopNav from "../components/TopNav";
import StatCard from "../components/StatCard";
import StatusBadge from "../components/StatusBadge";
import { currentOfficer, getDashboardStats, getActiveTenders } from "../data/mockData";

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [tenders, setTenders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    getDashboardStats().then(setStats); // GET /dashboard/stats
    getActiveTenders().then(setTenders); // GET /tenders?status=active
  }, []);

  return (
    <div className="min-h-screen bg-surface">
      <TopNav />

      <main className="mx-auto max-w-7xl px-6 py-8">
        {/* Welcome banner */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-xl bg-navy-950 p-6 text-white">
          <div>
            <h1 className="text-xl font-bold">Welcome Back, {currentOfficer.name}</h1>
            <p className="mt-1 text-sm text-white/70">
              You have 17 bids pending AI-assisted compliance verification for Q1 Petroleum supplies.
            </p>
          </div>
          <button className="shrink-0 rounded-md bg-petrol-500 px-4 py-2 text-sm font-semibold hover:bg-petrol-600">
            Initiate Verification
          </button>
        </div>

        {/* Stat cards */}
        {stats && (
          <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Active Tenders" value={stats.activeTenders.value} subtext={stats.activeTenders.subtext} accent="petrol" />
            <StatCard label="Bids Received" value={stats.bidsReceived.value} subtext={stats.bidsReceived.subtext} accent="pass" />
            <StatCard label="Pending Verification" value={stats.pendingVerification.value} subtext={stats.pendingVerification.subtext} accent="warn" />
            <StatCard label="High Risk Bidders Flagged" value={stats.highRiskFlagged.value} subtext={stats.highRiskFlagged.subtext} accent="fail" />
          </div>
        )}

        {/* Tenders table */}
        <div className="rounded-xl border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h2 className="text-base font-semibold text-navy-950">Active Tenders &amp; Bid Verification Status</h2>
            <button className="text-sm font-medium text-petrol-600 hover:underline">View All Tenders</button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border text-navy-800/60">
                  <th className="px-5 py-3 font-medium">Tender ID</th>
                  <th className="px-5 py-3 font-medium">Tender Title</th>
                  <th className="px-5 py-3 font-medium">Bidders</th>
                  <th className="px-5 py-3 font-medium">AI Status</th>
                  <th className="px-5 py-3 font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {tenders.map((t) => (
                  <tr key={t.id} className="border-b border-border last:border-b-0 hover:bg-surface">
                    <td className="px-5 py-3 font-medium text-navy-950">{t.id}</td>
                    <td className="px-5 py-3 text-navy-800">{t.title}</td>
                    <td className="px-5 py-3 text-navy-800">{t.bidders} Bidders</td>
                    <td className="px-5 py-3">
                      <StatusBadge status={t.status} />
                    </td>
                    <td className="px-5 py-3">
                      <button
                        onClick={() => navigate(`/tenders/${encodeURIComponent(t.id)}`)}
                        className="rounded-md border border-petrol-600 px-3 py-1.5 text-xs font-semibold text-petrol-600 hover:bg-petrol-600 hover:text-white"
                      >
                        Verify Bids
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
