export default function ChecklistItem({ label, status, note }) {
  const isPass = status === "PASS";
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border py-3 last:border-b-0">
      <div>
        <p className="text-sm font-medium text-navy-950">{label}</p>
        {note && <p className="mt-0.5 text-xs text-navy-800/60">{note}</p>}
      </div>
      <span
        className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
          isPass ? "bg-status-pass-bg text-status-pass" : "bg-status-fail-bg text-status-fail"
        }`}
        aria-label={status}
        title={status}
      >
        {isPass ? "✓" : "✕"}
      </span>
    </div>
  );
}
