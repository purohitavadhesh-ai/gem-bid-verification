import { NavLink } from "react-router-dom";
import { currentOfficer } from "../data/mockData";

const LINKS = [
  { to: "/dashboard", label: "Dashboard" },
  { to: "/tenders", label: "Tenders" },
  { to: "/bidders", label: "Bidders" },
  { to: "/verification", label: "Verification" },
  { to: "/reports", label: "Reports" },
  { to: "/audit-trail", label: "Audit Trail" },
];

export default function TopNav() {
  return (
    <header className="border-b border-border bg-navy-950 text-white">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-petrol-500 text-sm font-bold">
            GeM
          </div>
          <div className="leading-tight">
            <p className="text-[11px] uppercase tracking-wide text-white/60">
              Ministry of Petroleum &amp; Natural Gas
            </p>
            <p className="text-sm font-semibold">AI Bid Compliance Verification Platform</p>
          </div>
        </div>

        <nav className="flex flex-wrap items-center gap-1">
          {LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                  isActive ? "bg-petrol-600 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-petrol-500 text-xs font-bold">
            {currentOfficer.name.split(" ").map((n) => n[0]).join("")}
          </div>
          <div className="leading-tight text-right">
            <p className="text-sm font-medium">{currentOfficer.name}</p>
            <p className="text-[11px] text-white/60">{currentOfficer.role}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
