import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import BidderAnalysis from "./pages/BidderAnalysis";
import SecurityInsights from "./pages/SecurityInsights";
import AuditTrail from "./pages/AuditTrail";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/tenders/:tenderId" element={<BidderAnalysis />} />
        <Route path="/security" element={<SecurityInsights />} />
        <Route path="/audit-trail" element={<AuditTrail />} />
        {/* Placeholder routes referenced by TopNav, wired to real screens later */}
        <Route path="/tenders" element={<Navigate to="/dashboard" replace />} />
        <Route path="/bidders" element={<Navigate to="/dashboard" replace />} />
        <Route path="/verification" element={<Navigate to="/security" replace />} />
        <Route path="/reports" element={<Navigate to="/audit-trail" replace />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
